
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Registration Form</title>
	<style>
		
		fieldset{
			width: 600px;
			background-color: grey;
			color: white;
			border-radius: 10px;
		}
		legend{
			background-color: navy;
			color: white;
			font-family: cursive;
			font-size: x-large;
		}
		h1 {
           background-color: tomato;
           width: 500px;
           height: 60px;
           padding-top: 10px;
           border-radius: 35px;
           box-shadow: 5px 10px 15px lightsalmon;
           font-family: cursive;
          }
    input{
		     font-size: 17px;
		     border-radius: 5px;
		     border: none;
		     margin: 5px;
		}
		input[name="register"]:hover{
			background-color: green;
			color: white;
		}
    input[name="reset"]:hover{
			background-color: red;
			color: white;
		}     
	</style>
</head>
<body>
	   <center>
	   	      <h1>Registration Form</h1>
	   		<p style="color:<?= $_GET['color']??'';?>"><b><?= $_GET['msg']??"";?></b></p>
	   	<fieldset>
	   		<legend>Register Here..</legend>
	   		<form action="process.php" method="POST">
	   			<table>
	   				<tr>
	   				 <td><label> First Name: </label></td>
	   				 <td> <input type="text" name="first_name" id="first_name"></td>
	   				 </tr>

	   				<tr>
	   				 <td><label> Last Name: </label></td>
	   				 <td> <input type="text" name="last_name" id="last_name"></td>
	   				 </tr>

	   				<tr>
	   				 <td><label> Email: </label></td>
	   				 <td> <input type="email" name="email" id="email"></td>
	   				 </tr>
             
             <tr>
	   				 <td><label> Password: </label></td>
	   				 <td> <input type="password" name="password" id="password"></td>
	   				 </tr>

	   				<tr>
	   				 <td><label> CNIC Number: </label></td>
	   				 <td> <input type="text" name="cnic_number" id="cnic_number"></td>
	   				</tr>

	   				<tr>
	   				 <td><label> Phone Number: </label></td>
	   				 <td> <input type="text" name="phone_number" id="phone_number"></td>
	   				 </tr>

	   				<tr>
	   					<td><label>Country: </label></td>
	   					<td>
	   						<select name="country" id="country">
	   							<option value="">...select country...</option>
	   							<option value="Paksitan">Paksitan</option>
	   							<option value="Turkey">Turkey</option>
	   							<option value="Afghanistan">Afghanistan</option>
	   						</select>
	   					</td>
	   				</tr>

	   				<tr>
	   				  <td><label>Gender: </label></td>
	   				<td>Male<input type="radio" name="gender"  value="Male">
	   			     Female<input type="radio" name="gender"  value="Female">
              </td>
	   				</tr>


	   				<tr>
	   					<td><input type="submit" name="register" value="Register"></td>
              <td> <input type="reset" name="reset" value="Cancel"> </td>
	   				</tr>
	   			</table>
	   		</form>
	   	</fieldset>
	   	<p>If you have already account <a href="login.php">Click Here</a> for login...</p>
	   </center>
               
</body>
</html>








  
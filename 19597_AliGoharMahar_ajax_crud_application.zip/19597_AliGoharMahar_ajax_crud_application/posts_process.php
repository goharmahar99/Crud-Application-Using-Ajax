<?php
session_start();
require_once("require/connection.php");
require_once("require/database_driver.php");

$blog_management_ajax = new blog_management_ajax($hostname,$username,$password,$database);

extract($_REQUEST);

if(isset($_REQUEST['action']) && $_REQUEST['action']=="add_post"){
$post_title = htmlspecialchars($post_title,true);
$post_description = htmlspecialchars($post_description,true);
$query = "INSERT INTO post values('null','".$_SESSION['user_info']['user_id']."','".$post_title."','".$post_description."')";

$execute = $blog_management_ajax->execute_query($query);

if($execute){
echo "<p style='color:white; background-color:green; width:500px; border-radius:10px;font-size:20px'>Post ID: ".mysqli_insert_id($blog_management_ajax->connection)." Has Been Successfully Added...</p>";
}else{
echo "<p style='color:white; background-color:red; width:500px; border-radius:10px;font-size:20px'>Post Not Added...</p>";

}

}
elseif(isset($_REQUEST['action']) && $_REQUEST['action']=="show_post"){
		$query = "SELECT * FROM post ORDER BY post_id DESC";

		$execute = $blog_management_ajax->execute_query($query);

		if($execute->num_rows > 0){

  	       ?>
   
    <table border="2">
   	   <tr>
   	   	<th>Post_id</th>
   	   	<th>User_Id</th>
   	   	<th>Post Title</th>
   	   	<th>Post Description</th>
   	   	<th>Operation</th>
      </tr>
      <?php 
       while($row = mysqli_fetch_assoc($execute)){
       	  extract($row);
           ?>
       <tr>
      	<td><?= $post_id;?></td>
      	<td><?= $user_id;?></td>
      	<td><?= $post_title;?></td>
      	<td><?= $post_description;?></td>
      	<td>
      	  <button onclick="edit_post(<?= $post_id?>)" style="background-color: green;color: white;">Update</button>
      	  <button onclick="deletePost(<?= $post_id?>)" style="background-color:red;color: white;">Delete</button>

      	</td>
      </tr>
      <?php 
      }
      ?>
   </table>
   <?php
 }
}
elseif(isset($_REQUEST['action']) && $_REQUEST['action']=="edit_post"){
$query = "SELECT * FROM post WHERE post_id = '".$post_id."'";

$execute = $blog_management_ajax->execute_query($query);

if($execute->num_rows){
  
    $row = mysqli_fetch_assoc($execute);
    extract($row);
     ?>
    <fieldset>
	    		<legend>Update Post</legend>
	    		 <form action="" method="" id="form_info">
	    			<table cellpadding="5" cellspacing="5">
	    				<tr>
	    				<th>Post Title : </th>
	    				<td> <input type="text" name="post_title" value="<?=$post_title;?>"></td>
	    				</tr>

	    				<tr>
	    				<th>Post Description : </th>
	    				 <td><textarea name="post_description" cols="27" rows="8"><?=$post_description;?></textarea></td>
	    				</tr>
	    				<tr align="center">
	    					<td colspan="2"><button type="button" name="update_post" id="add_post" onclick="updatePost(<?=$post_id;?>)">Update Post</button>
	    					<button type="button" name="reset">Reset</button></td>

	    				</tr>
	    			</table>
                 </form>
	    	</fieldset>

 <?php
 }

}elseif(isset($_REQUEST['action']) && $_REQUEST['action']=="update_post"){
$post_title = htmlspecialchars($post_title,true);
$post_description = htmlspecialchars($post_description,true);
$query = "UPDATE post SET post_title = '".$post_title."',post_description = '".$post_description."' 
            WHERE post_id = '".$post_id."'";

$execute = $blog_management_ajax->execute_query($query);

if($execute){
echo "<p style='color:white; background-color:green; width:500px; border-radius:10px;font-size:20px'>Post ID: ".$post_id." Has Been Updated Successfully...</p>";
}else{
echo "<p style='color:white; background-color:red; width:500px; border-radius:10px;font-size:20px'>Post Not Updated...</p>";

}

}elseif(isset($_REQUEST['action']) && $_REQUEST['action']=="delete_post"){

$query = "DELETE FROM post WHERE post_id = '".$post_id."'";

$execute = $blog_management_ajax->execute_query($query);

if($execute){
echo "<p style='color:white; background-color:green; width:500px; border-radius:10px;font-size:20px'>Post ID: ".$post_id." Has Been Deleted Successfully...</p>";
}else{
echo "<p style='color:white; background-color:red; width:500px; border-radius:10px;font-size:20px'>Post Not Deleted...</p>";

}

}
elseif(isset($_REQUEST['action']) && $_REQUEST['action']=="Search_Post"){

$query = "SELECT * FROM post WHERE post_title like '%{$searchpost}%'";

$execute = $blog_management_ajax->execute_query($query);

if($execute->num_rows > 0){

 ?>
   
    <table border="2">
   	   <tr>
   	   	<th>Post_id</th>
   	   	<th>User_Id</th>
   	   	<th>Post Title</th>
   	   	<th>Post Description</th>
   	   	<th>Operation</th>
      </tr>
      <?php 
       while($row = mysqli_fetch_assoc($execute)){
       	  extract($row);
           ?>
       <tr>
      	<td><?= $post_id;?></td>
      	<td><?= $user_id;?></td>
      	<td><?= $post_title;?></td>
      	<td><?= $post_description;?></td>
      	<td>
      	  <button onclick="edit_post(<?= $post_id?>)" style="background-color: green;color: white;">Update</button>
      	  <button onclick="deletePost(<?= $post_id?>)" style="background-color:red;color: white;">Delete</button>

      	</td>
      </tr>
      <?php 
      }
      ?>
   </table> 
  <?php
      }
    }
?>
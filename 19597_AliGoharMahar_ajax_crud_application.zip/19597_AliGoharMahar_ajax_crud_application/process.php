<?php
session_start();
require_once("require/connection.php");
require_once("require/database_driver.php");

$blog_management_ajax = new blog_management_ajax($hostname,$username,$password,$database);

if(isset($_REQUEST['register'])){
  
extract($_REQUEST);

$query = "INSERT INTO users values('null','{$first_name}','{$last_name}','{$email}','{$password}','{$cnic_number}','{$phone_number}','{$country}','{$gender}')";

 $execute = $blog_management_ajax->execute_query($query);

 if($execute){
     header("location: index.php?msg=Record Inserted Successfully&color=green");
 }else{
     header("location: index.php?msg=Record Not Inserted&color=red");
 }
}elseif(isset($_REQUEST['login'])){
    // echo "<pre>";
    //  print_r($_REQUEST);
    // echo "</pre>";
   extract($_REQUEST);
  $query = "SELECT * FROM users where email = '{$email}' AND password = '{$password}'";
  echo $query;
  $execute = $blog_management_ajax->execute_query($query);
  
  if($execute->num_rows>0){
  	 $row = mysqli_fetch_assoc($execute);
  	$_SESSION['user_info'] = $row;
  	//    echo "<pre>";
    //  print_r($_SESSION['user_info']);
    // echo "</pre>";
  	// die;
     header("location: dashboard.php");
 }else{
     header("location: login.php?msg=Invaid Passwoord or Username...&color=red");
 }
}





?>
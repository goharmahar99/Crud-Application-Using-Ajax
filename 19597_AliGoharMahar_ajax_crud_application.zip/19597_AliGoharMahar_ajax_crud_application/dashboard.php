<?php
session_start();
    if(!$_SESSION['user_info']['user_id']){
    header("location:login.php?msg=Please Login First&color=red");
}        

?>

<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>User Dashboard</title>
	<style>
		h1 {
           background-color: grey;
           color: white;
           width: 500px;
           height: 60px;
           padding-top: 10px;
           border-radius: 35px;
           box-shadow: 5px 10px 10px lightgrey;
           font-family: cursive;
          }
          fieldset{
			 width: 500px;
			 height: auto;
			 background-color: lightgray;
			 border-radius: 10px;
		}
		legend{
			background-color: navy;
			border-radius: 10px;
			color: white;
			font-family: cursive;
		}
		
		input{
		     font-size: 17px;
		     border-radius: 5px;
		}
		button[type="button"]{
			background-color: green;
            padding: 5px;
            border-radius: 5px;
			color: white;			
		}
		button[name="reset"]{
			background-color: red;
			color: white;
		}
		#logout{
			float: right;
			background-color: red;
			border-radius: 10px;
		}
		#logout a{
			color: white;
			font-size: 20px;
			text-decoration: none;
		}
	</style>
	<script>

		  function AddPost(){
		 // alert("Ok");
		  	var form_info = document.getElementById('form_info');
		  	var form_data = new FormData(form_info);
		  	form_data.append("action","add_post");
		 	var obj = new XMLHttpRequest();
		 	obj.onreadystatechange = function(){
                if(obj.readyState == 4 && obj.status == 200){
                   document.getElementById('msg').innerHTML = obj.responseText;

                   show_posts();
                }
		 	}

		 	obj.open("POST","posts_process.php");
		 	obj.send(form_data);
		  }

		  function show_posts(){
		  	var form_data = new FormData(form_info);
		  	form_data.append("action","show_post");
		 	var obj = new XMLHttpRequest();
		 	obj.onreadystatechange = function(){
                if(obj.readyState == 4 && obj.status == 200){
                   document.getElementById('myPosts').innerHTML = obj.responseText;
                   //console.log(obj.responseText);
                }
		 	}

		 	 obj.open("POST","posts_process.php");
		 	 obj.send(form_data);
		  }
          function edit_post($id){
		  	var form_info = document.getElementById('form_info');
		  	var form_data = new FormData(form_info);
		  	form_data.append("action","edit_post");
		  	form_data.append("post_id",$id);
		  	
		 	var obj = new XMLHttpRequest();
		 	obj.onreadystatechange = function(){
                if(obj.readyState == 4 && obj.status == 200){
                   document.getElementById('form_data').innerHTML = obj.responseText;
                     show_posts();
                }
		 	}

		 	 obj.open("POST","posts_process.php");
		 	 obj.send(form_data);
		  }

		  function updatePost($id){
		  	//alert("Ok");
		  	if(confirm("Do you want to update post..")){
		  	var form_info = document.getElementById('form_info');
		  	var form_data = new FormData(form_info);
		  	form_data.append("action","update_post");
		  	form_data.append("post_id",$id);
		  	
		 	var obj = new XMLHttpRequest();
		 	obj.onreadystatechange = function(){
                if(obj.readyState == 4 && obj.status == 200){
                  document.getElementById('msg').innerHTML = obj.responseText;
                    //console.log(obj.responseText);
                  show_posts();
                 

                  
                  document.getElementById('form_data').innerHTML = AddPostForm();
                }
		 	}

		 	 obj.open("POST","posts_process.php");
		 	 obj.send(form_data);
		 	}
		  }

		  function AddPostForm(){
		  	return '<fieldset><legend>Add Post</legend><form action="" method="" id="form_info"><table cellpadding="5" cellspacing="5"><tr><th>Post Title : </th><td> <input type="text" name="post_title"></td></tr><tr><th>Post Description : </th><td><textarea name="post_description" cols="27" rows="8"></textarea></td></tr><tr align="center"><td colspan="2"><button type="button" name="add_post" id="add_post" onclick="AddPost()">Add Post</button><button type="button" name="reset">Reset</button></td></tr></table></form></fieldset>';
		  }

		  function deletePost($id){
		  	//alert($id);
		  	if(confirm("Do you want to delete this post....")){
		  	var form_info = document.getElementById('form_info');
		  	var form_data = new FormData(form_info);
		  	form_data.append("action","delete_post");
		  	form_data.append("post_id",$id);
		  	
		 	var obj = new XMLHttpRequest();
		 	obj.onreadystatechange = function(){
                if(obj.readyState == 4 && obj.status == 200){
                  document.getElementById('msg').innerHTML = obj.responseText;
                    //console.log(obj.responseText);
                  show_posts();
                }
		 	}

		 	 obj.open("POST","posts_process.php");
		 	 obj.send(form_data);
		 	}
		  }

		  function searchPost(){
		 
		  	 var search_post = document.getElementById('search_post').value;
		  	
		 	var obj = new XMLHttpRequest();
		 	obj.onreadystatechange = function(){
                if(obj.readyState == 4 && obj.status == 200){
                 document.getElementById('myPosts').innerHTML = obj.responseText;

                }
		 	}

		 	 obj.open("GET","posts_process.php?action=Search_Post&searchpost="+search_post);

		 	 obj.send();
		 	
		  }
	</script>
</head>
<body onload="show_posts()"> 
	  <center>
	    <h1>User Dashboard</h1>
          <div id="msg"></div>
                 <button id="logout"><a href="logout.php">Logout</a></button>
        <div id="form_data">
        <fieldset>
	    		<legend>Add Post</legend>
	    		 <form action="" method="" id="form_info">
	    			<table cellpadding="5" cellspacing="5">
	    				<tr>
	    				<th>Post Title : </th>
	    				<td> <input type="text" name="post_title"></td>
	    				</tr>

	    				<tr>
	    				<th>Post Description : </th>
	    				 <td><textarea name="post_description" cols="27" rows="8"></textarea></td>
	    				</tr>
	    				<tr align="center">
	    					<td colspan="2"><button type="button" name="add_post" id="add_post" onclick="AddPost()">Add Post</button>
	    					<button type="button" name="reset">Reset</button></td>

	    				</tr>
	    			</table>
                 </form>
	    	</fieldset>
	    </div>
	    <br>


          <div>
          	<form action="">
            <table>
             <tr>
              <td>Search Post:</td>
              <td><input id="search_post" type="text" name="search_post" placeholder="Enter Post Title"></td>
             </tr>
             <tr>
             	<td colspan="2" align="center"> <button type="button" onclick="searchPost()">Search Post</button> </td>
             </tr>
           </table>
           </form>
              </div>

               <br><br>
	   	<div id="myPosts"></div>
	  </center>
</body>
</html>